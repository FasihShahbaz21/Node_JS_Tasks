// Task 1
/*Task 1: Write a function that takes an array of integers as input and 
returns the the count of even numbers.*/

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

var count = 0;

var evens = arr.filter(function (x) {
  if (x % 2 == 0) {
    count++;
  }
  return count;
});
console.log(count);
