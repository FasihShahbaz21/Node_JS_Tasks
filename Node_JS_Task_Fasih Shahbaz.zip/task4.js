// Task 4
/*Task 4: Create a function that takes in an array of numbers and returns a 
resultant array after transforming the input array into an array of cubes of
its elements. (Your function must not exceed one line of code)
var arr1=[3,4,5];*/

arr1.forEach(function (value, index, arr1) 
{
  return (arr1[index] = value * value * value);
});

console.log(arr1);
