// Task 10
/*Task 10: Create a function that takes a string and an array of strings as 
input. It then returns true or false based on the condition that the input 
string is present in the array of strings. The search should be case insensitive.*/
var arr = ["Hello", "Pakistan", "Fasih"];

var str = "fasIh";

function check(arr) 
{
  return arr.some((elem) => elem.toLowerCase() === str.toLowerCase());
}

var x = check(arr);

console.log(x);
