/*Task 11: Create a function that takes in an array of numbers or strings 
and returns true or false if the elements in the array form a palindrome 
when traversed in order.*/

function palindrome(str) 
{
  var palin = str.split("").reverse().join("");

  if (palin === str) 
  {
    return true;
  } 
  else {
    return false;
  }
}

console.log(palindrome("eye"));

console.log(palindrome("Hello"));
