// task 12
/*Task 12: Prove with code that data types in Javascript have Truthy and 
Falsey values.*/

var x = 0;
var y = 1;
var str = "";
var str1 = "Cool";
var arr = [];
if (x) {
  console.log("Hello its truthy");
} else {
  console.log("It is Falsy");
}

if (y) {
  console.log("Hello its truthy");
} else {
  console.log("It is Falsy");
}

if (str) {
  console.log("Hello its truthy");
} else {
  console.log("It is Falsy");
}

if (str1) {
  console.log("Hello its truthy");
} else {
  console.log("It is Falsy");
}

if (arr) {
  console.log("Hello its truthy");
} else {
  console.log("It is Falsy");
}
