// task 8
/*Task 8: Create a function that takes an array of numbers as input and 
returns true or false based on the condition that every number is even.
Hint: Search for Array.every() method.*/
var arr2 = [2,4,6,8];

var evens = arr2.every(checkEven);

console.log(evens);

function checkEven(arr2) 
{
    return arr2 % 2 == 0;
}