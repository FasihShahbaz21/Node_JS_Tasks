// task 2
/*Task 2: Create a custom object. Sort that object by its keys and return the 
corresponding values of those sorted keys in an array.*/
var obj={
zain:45,
ali:22,
hamza:12
}

Object.values(obj);

console.log(Object.values(obj).sort());