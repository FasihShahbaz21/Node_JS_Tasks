// Task 16
/*Task 16: Create a function that generates a string id of input length n of 
random characters.*/
var text = "";
var char_list =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

function makeid(l) 
{
  for (var i = 0; i < l; i++)
   {
    text += char_list.charAt(Math.floor(Math.random() * char_list.length));
  }

  return text;
}

console.log(makeid(7));
