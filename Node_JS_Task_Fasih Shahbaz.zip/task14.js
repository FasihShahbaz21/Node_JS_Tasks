// Task 14
/*Task 14: Create a function that accepts a string as input and returns a 
resultant string with the first letter of each word of the string in upper
case.*/

const str = "welcome friend, how have you been";

const strToArr = str.split(" ");

//console.log(strToArr);
function StringConversion(str) 
{
  return strToArr.map((word) => word[0].toUpperCase() + word.substring(1));
}
const allFirstToUC = StringConversion(str);

console.log(allFirstToUC);

const newStr = allFirstToUC.join(" ");

console.log(newStr);
