// task 3
/*Task 3: Create a function that takes an array of custom objects Users and 
returns an array of all the users that live in a certain country. (Your 
function must not exceed one line of code)*/
var objarr = {
'User':
[
{user: 'Fasih',country:'Pakistan'},
{User1: 'Ali',country:'Pakistan'},
{User2: 'Hamza',country:'America'},
]
};

var list = objarr.User.filter(function(x){ return x.country=='Pakistan' })

console.log(list);