// task 9
/*Task 9: Without using a loop initialize an array with first 1000 natural 
numbers.
Hint: Search Array.fill()*/

function Making(n) {
  return Array(n)
    .fill(0)
    .map((val, index) => {
      return index + 1;
    });
}
var x = Making(1000);
console.log(x);
