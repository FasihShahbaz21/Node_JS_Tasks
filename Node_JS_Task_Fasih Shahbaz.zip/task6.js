// task 6
/*Task 6: Given an array of numbers. Find the index of the first 
occurrence of the most frequent element in it. If all elements have the 
same frequency return -1.*/

var arr=[1,1,1,2,3,4]

var occurence=arr.indexOf(1);

console.log(occurence);





