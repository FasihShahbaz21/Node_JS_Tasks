// Task-15
/*Task 15: Create a function that takes an array of country names and 
returns the country that has the longest name. If two or more countries 
have the same largest length then return the first occurrence.*/

var arr1 = ["Canda", "Pakistan","Pakistani Zindabaad"];
var largestString = arr1.reduce(function (a, b) {
  return a.length > b.length ? a:b ;
});
console.log(largestString);
