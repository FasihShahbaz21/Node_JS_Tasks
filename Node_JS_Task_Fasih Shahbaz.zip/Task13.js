// task 13
/*Task 13: Create a function to generate a random integer. And build a 
small dice game.
Hint: Explore Math library and how to take user input in Javascript*/
function random() {
  return Math.floor(Math.random() * 6 + 1);
}

var x = random();

console.log(x);
