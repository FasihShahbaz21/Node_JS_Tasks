// Task 5
/*Task 5: Create a function that takes in a string and a substring and 
returns true or false based on the condition that substring exists in the 
given string.*/

var str="Hello World";

var str1="llo";

str=str.includes(str1);

console.log(str);
